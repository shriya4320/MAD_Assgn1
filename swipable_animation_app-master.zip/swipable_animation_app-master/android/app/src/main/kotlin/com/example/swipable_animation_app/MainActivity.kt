package com.example.swipable_animation_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
